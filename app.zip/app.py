from flask import Flask, request, jsonify, render_template, send_file, make_response, redirect, url_for, flash
import os
import time
import subprocess
import json
from dotenv import load_dotenv
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
import PyPDF2
import docx
import textwrap
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import sqlite3
from functools import wraps

# Load .env explicitly (assumes .env is in same folder as app.py)
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(dotenv_path)

print("Loaded GROQ_API_KEY:", os.getenv('GROQ_API_KEY'))

app = Flask(__name__)
CORS(app, supports_credentials=True)  # Added supports_credentials=True
app.secret_key = os.getenv('SECRET_KEY', 'your-secret-key-here')

# Configuration
app.config.update({
    'GROQ_API_KEY': os.getenv('GROQ_API_KEY'),
    'GROQ_API_URL': 'https://api.groq.com/openai/v1/chat/completions',
    'MODEL': 'llama3-70b-8192',  # Change as needed or from .env
    'UPLOAD_FOLDER': 'uploads',
    'ALLOWED_EXTENSIONS': {'pdf', 'docx', 'txt'},
    'MAX_CONTENT_LENGTH': 16 * 1024 * 1024,  # 16MB max
    'DATABASE': 'users.db'
})

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, username, email):
        self.id = id
        self.username = username
        self.email = email

# Database setup
def get_db():
    db = sqlite3.connect(app.config['DATABASE'])
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with app.app_context():
        db = get_db()
        db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        db.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                filepath TEXT NOT NULL,
                extracted_text TEXT,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        db.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                question TEXT NOT NULL,
                answer TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        db.commit()

# Initialize database
init_db()

@login_manager.user_loader
def load_user(user_id):
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    db.close()
    if user:
        return User(id=user['id'], username=user['username'], email=user['email'])
    return None

def login_required_json(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    return decorated_function

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# User management routes
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not username or not email or not password:
            flash('All fields are required', 'error')
            return redirect(url_for('register'))
        
        db = get_db()
        try:
            password_hash = generate_password_hash(password)
            db.execute(
                'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                (username, email, password_hash)
            )
            db.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists', 'error')
        finally:
            db.close()
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        db.close()
        
        if user and check_password_hash(user['password_hash'], password):
            user_obj = User(id=user['id'], username=user['username'], email=user['email'])
            login_user(user_obj)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('home'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "Logged out successfully"})

@app.route('/api/check_auth')
def check_auth():
    if current_user.is_authenticated:
        return jsonify({
            "authenticated": True,
            "username": current_user.username
        })
    return jsonify({"authenticated": False})

# Helper functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def extract_text_from_file(filepath):
    if filepath.endswith('.pdf'):
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            return '\n'.join([page.extract_text() or '' for page in reader.pages])
    elif filepath.endswith('.docx'):
        doc = docx.Document(filepath)
        return '\n'.join([para.text for para in doc.paragraphs])
    elif filepath.endswith('.txt'):
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

def call_groq_with_messages(messages, max_tokens=1024):
    api_key = app.config['GROQ_API_KEY']
    model = app.config['MODEL']
    url = app.config['GROQ_API_URL']

    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": max_tokens,
        "top_p": 1
    }

    try:
        curl_command = [
            "curl", "-s", url,
            "-H", "Content-Type: application/json",
            "-H", f"Authorization: Bearer {api_key}",
            "-d", json.dumps(payload)
        ]

        result = subprocess.run(curl_command, capture_output=True, text=True, check=True)
        response_json = json.loads(result.stdout)
        if "choices" in response_json:
            return response_json['choices'][0]['message']['content']
        elif "error" in response_json:
            raise Exception(f"Groq API error: {response_json['error'].get('message', 'Unknown error')}")
        else:
            raise Exception(f"Unexpected response: {response_json}")

    except subprocess.CalledProcessError as e:
        print("Curl error:", e.stderr)
        raise Exception("Groq API call failed using curl")
    except Exception as e:
        print("General error:", str(e))
        raise

def call_groq(prompt, system_message=None, max_tokens=1024):
    return call_groq_with_messages(
        messages=[
            {"role": "system", "content": system_message or "You're a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=max_tokens
    )

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
@login_required_json
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        try:
            filename = secure_filename(file.filename)
            user_upload_dir = os.path.join(app.config['UPLOAD_FOLDER'], str(current_user.id))
            os.makedirs(user_upload_dir, exist_ok=True)
            filepath = os.path.join(user_upload_dir, filename)
            file.save(filepath)

            extracted_text = extract_text_from_file(filepath)

            # Store document in database
            db = get_db()
            db.execute(
                'INSERT INTO documents (user_id, filename, filepath, extracted_text) VALUES (?, ?, ?, ?)',
                (current_user.id, filename, filepath, extracted_text)
            )
            db.commit()
            db.close()

            return jsonify({
                "message": "File uploaded and text extracted successfully",
                "filename": filename,
                "text_preview": textwrap.shorten(extracted_text, width=300, placeholder="...")
            })

        except Exception as e:
            return jsonify({"error": f"Error processing file: {str(e)}"}), 500

    return jsonify({"error": "File type not allowed"}), 400

@app.route('/chat', methods=['POST'])
@login_required_json
def chat():
    try:
        data = request.json
        prompt = data.get('prompt')
        use_context = data.get('use_context', True)  # Default to using context

        if not prompt:
            return jsonify({"error": "Empty prompt"}), 400

        # Get the last 5 messages for context
        db = get_db()
        if use_context:
            previous_messages = db.execute(
                '''SELECT question, answer FROM chat_history 
                WHERE user_id = ? 
                ORDER BY timestamp DESC LIMIT 5''',
                (current_user.id,)
            ).fetchall()
            previous_messages = reversed(previous_messages)  # Put in chronological order
        else:
            previous_messages = []

        # Build the conversation history
        messages = [{
            "role": "system",
            "content": "You're an expert AI assistant. Keep responses concise but accurate."
        }]

        # Add previous Q&A pairs to context
        for msg in previous_messages:
            messages.append({
                "role": "user",
                "content": msg['question']
            })
            messages.append({
                "role": "assistant",
                "content": msg['answer']
            })

        # Add the new prompt
        messages.append({
            "role": "user",
            "content": prompt
        })

        # Call Groq with full context
        response = call_groq_with_messages(
            messages=messages,
            max_tokens=1500
        )

        # Store in chat history
        db.execute(
            'INSERT INTO chat_history (user_id, question, answer) VALUES (?, ?, ?)',
            (current_user.id, prompt, response)
        )
        db.commit()
        db.close()

        return jsonify({
            "response": response,
            "model": app.config['MODEL'],
            "timestamp": time.time(),
            "context_used": use_context
        })

    except Exception as e:
        return jsonify({
            "error": str(e),
            "solution": "Check your GROQ_API_KEY or try again later"
        }), 500

@app.route('/chat/history', methods=['GET'])
@login_required_json
def get_chat_history():
    try:
        limit = request.args.get('limit', default=10, type=int)
        offset = request.args.get('offset', default=0, type=int)

        db = get_db()
        chats = db.execute(
            '''SELECT id, question, answer, timestamp 
            FROM chat_history 
            WHERE user_id = ? 
            ORDER BY timestamp DESC 
            LIMIT ? OFFSET ?''',
            (current_user.id, limit, offset)
        ).fetchall()
        
        total_chats = db.execute(
            'SELECT COUNT(*) FROM chat_history WHERE user_id = ?',
            (current_user.id,)
        ).fetchone()[0]
        
        db.close()

        return jsonify({
            "chats": [dict(chat) for chat in chats],
            "total": total_chats,
            "limit": limit,
            "offset": offset
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/chat/clear', methods=['POST'])
@login_required_json
def clear_chat_history():
    try:
        db = get_db()
        db.execute(
            'DELETE FROM chat_history WHERE user_id = ?',
            (current_user.id,)
        )
        db.commit()
        db.close()
        return jsonify({"message": "Chat history cleared"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/ask', methods=['POST'])
@login_required_json
def ask_question():
    try:
        data = request.json
        question = data.get('question')
        use_context = data.get('use_context', True)

        if not question:
            return jsonify({"error": "No question provided"}), 400

        # Get the most recent document for the user
        db = get_db()
        document = db.execute(
            'SELECT extracted_text FROM documents WHERE user_id = ? ORDER BY uploaded_at DESC LIMIT 1',
            (current_user.id,)
        ).fetchone()

        if not document or not document['extracted_text'].strip():
            return jsonify({"error": "No document uploaded or text extracted yet"}), 400

        # Get previous Q&A about this document
        if use_context:
            previous_questions = db.execute(
                '''SELECT question, answer FROM chat_history 
                WHERE user_id = ? 
                ORDER BY timestamp DESC LIMIT 3''',
                (current_user.id,)
            ).fetchall()
            previous_questions = reversed(previous_questions)
        else:
            previous_questions = []

        # Build the prompt with context
        messages = [{
            "role": "system",
            "content": f"""You're an expert document analyst. Answer questions based strictly on the provided document content.
            Current Document Content:
            {document['extracted_text']}
            
            If the answer is not in the document, say you don't know."""
        }]

        # Add previous Q&A pairs
        for qa in previous_questions:
            messages.append({
                "role": "user",
                "content": qa['question']
            })
            messages.append({
                "role": "assistant",
                "content": qa['answer']
            })

        # Add the current question
        messages.append({
            "role": "user",
            "content": question
        })

        response = call_groq_with_messages(
            messages=messages,
            max_tokens=1500
        )

        # Store in chat history
        db.execute(
            'INSERT INTO chat_history (user_id, question, answer) VALUES (?, ?, ?)',
            (current_user.id, question, response)
        )
        db.commit()
        db.close()

        return jsonify({
            "answer": response,
            "model": app.config['MODEL'],
            "context_used": use_context
        })

    except Exception as e:
        return jsonify({
            "error": str(e),
            "solution": "Please try again later"
        }), 500

@app.route('/download/text', methods=['GET'])
@login_required
def download_text():
    """Download the extracted text as TXT or PDF"""
    format = request.args.get('format', 'txt').lower()
    
    db = get_db()
    document = db.execute(
        'SELECT extracted_text FROM documents WHERE user_id = ? ORDER BY uploaded_at DESC LIMIT 1',
        (current_user.id,)
    ).fetchone()
    db.close()

    if not document or not document['extracted_text'].strip():
        flash('No document text available to download', 'error')
        return redirect(url_for('home'))

    try:
        if format == 'txt':
            response = make_response(document['extracted_text'])
            response.headers['Content-Type'] = 'text/plain'
            response.headers['Content-Disposition'] = f'attachment; filename=extracted_text_{current_user.id}.txt'
            return response
        elif format == 'pdf':
            buffer = BytesIO()
            p = canvas.Canvas(buffer, pagesize=letter)
            text = p.beginText(40, 750)
            text.setFont("Helvetica", 12)
            
            for line in document['extracted_text'].split('\n'):
                for wrapped_line in textwrap.wrap(line, width=100):
                    text.textLine(wrapped_line)
            
            p.drawText(text)
            p.showPage()
            p.save()
            
            buffer.seek(0)
            return send_file(
                buffer,
                as_attachment=True,
                download_name=f'extracted_text_{current_user.id}.pdf',
                mimetype='application/pdf'
            )
        else:
            flash('Invalid format. Use "txt" or "pdf"', 'error')
            return redirect(url_for('home'))
    except Exception as e:
        flash(f'Failed to generate download: {str(e)}', 'error')
        return redirect(url_for('home'))

@app.route('/download/chat', methods=['GET'])
@login_required
def download_chat():
    """Download the chat history as TXT or PDF"""
    format = request.args.get('format', 'txt').lower()
    
    db = get_db()
    chats = db.execute(
        'SELECT question, answer FROM chat_history WHERE user_id = ? ORDER BY timestamp DESC',
        (current_user.id,)
    ).fetchall()
    db.close()

    if not chats:
        flash('No chat history available to download', 'error')
        return redirect(url_for('home'))

    try:
        chat_text = f"Chat History for {current_user.username}\n\n"
        for chat in chats:
            chat_text += f"Q: {chat['question']}\n"
            chat_text += f"A: {chat['answer']}\n\n"
            chat_text += "-" * 50 + "\n\n"

        if format == 'txt':
            response = make_response(chat_text)
            response.headers['Content-Type'] = 'text/plain'
            response.headers['Content-Disposition'] = f'attachment; filename=chat_history_{current_user.id}.txt'
            return response
        elif format == 'pdf':
            buffer = BytesIO()
            p = canvas.Canvas(buffer, pagesize=letter)
            text = p.beginText(40, 750)
            text.setFont("Helvetica", 12)
            
            for line in chat_text.split('\n'):
                for wrapped_line in textwrap.wrap(line, width=100):
                    text.textLine(wrapped_line)
            
            p.drawText(text)
            p.showPage()
            p.save()
            
            buffer.seek(0)
            return send_file(
                buffer,
                as_attachment=True,
                download_name=f'chat_history_{current_user.id}.pdf',
                mimetype='application/pdf'
            )
        else:
            flash('Invalid format. Use "txt" or "pdf"', 'error')
            return redirect(url_for('home'))
    except Exception as e:
        flash(f'Failed to generate download: {str(e)}', 'error')
        return redirect(url_for('home'))

@app.route('/profile')
@login_required
def profile():
    db = get_db()
    # Get user's document count
    doc_count = db.execute(
        'SELECT COUNT(*) FROM documents WHERE user_id = ?',
        (current_user.id,)
    ).fetchone()[0]
    
    # Get user's chat history count
    chat_count = db.execute(
        'SELECT COUNT(*) FROM chat_history WHERE user_id = ?',
        (current_user.id,)
    ).fetchone()[0]
    
    # Get recent documents
    recent_docs = db.execute(
        'SELECT filename, uploaded_at FROM documents WHERE user_id = ? ORDER BY uploaded_at DESC LIMIT 5',
        (current_user.id,)
    ).fetchall()
    
    db.close()
    
    return jsonify({
        "username": current_user.username,
        "email": current_user.email,
        "doc_count": doc_count,
        "chat_count": chat_count,
        "recent_docs": [dict(doc) for doc in recent_docs]
    })

# HTML Templates
@app.route('/templates/<template_name>')
def serve_template(template_name):
    if template_name not in ['index.html', 'login.html', 'register.html', 'profile.html']:
        return "Template not found", 404
    return render_template(template_name)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)